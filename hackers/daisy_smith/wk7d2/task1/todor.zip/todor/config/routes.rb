Rails.application.routes.draw do
  get 'priorities/index'

  root :to => 'users#index'
  resources :users, :only => [:index, :new, :create]
  resources :priorities, :only => [:index, :create]

  get '/login' => 'sessions#new'
  post '/login' => 'sessions#create'
  delete '/login' => 'sessions#destroy'
end
