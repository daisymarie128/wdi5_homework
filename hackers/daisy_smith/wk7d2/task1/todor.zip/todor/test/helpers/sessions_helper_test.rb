require 'test_helper'

class SessionsHelperTest < ActionView::TestCase
end
