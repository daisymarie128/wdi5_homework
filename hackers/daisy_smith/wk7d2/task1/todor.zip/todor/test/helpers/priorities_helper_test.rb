require 'test_helper'

class PrioritiesHelperTest < ActionView::TestCase
end
